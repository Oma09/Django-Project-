# weather_prediction/views.py
from django.shortcuts import render
import requests

def weather(request):
    api_key = 'YOUR_API_KEY'
    city = 'New York'  # Example city, replace it with your desired city
    url = f'http://api.weatherapi.com/v1/current.json?key={api_key}&q={city}'
    response = requests.get(url)
    data = response.json()
    weather_data = {
        'location': data['location']['name'],
        'temperature': data['current']['temp_c'],
        'condition': data['current']['condition']['text'],
    }
    return render(request, 'weather_prediction/weather.html', {'weather_data': weather_data})
